<?php

$conn = mysqli_connect('localhost','root','','tcc') or die('connection failed');

?>